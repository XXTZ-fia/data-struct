public class CS0445A2 {
    public static void main(String[] args) {
        String[] coapm = {"data/coapm"};
        Words.main(coapm);

        String[] blueChair = {"data/BlueChair"};
        Words.main(blueChair);

        ArrayProgram.main(null);

        ArrayListProgram.main(null);
    }
}
