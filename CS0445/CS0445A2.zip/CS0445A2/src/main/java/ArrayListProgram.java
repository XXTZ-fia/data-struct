/**
 * A vector of Strings program
 */
import java.util.ArrayList;

public class ArrayListProgram {

    public static void main(String args[]) {
        // Initialization of ArrayList, holding String objects
        ArrayList<String> words = new ArrayList<>(); 

        words.add("I");
        words.add("am");
        words.add("the");
        words.add("eggman");
		
		// The three operations
		// Operation 1

		// Operation 2

		// Operation 3

        System.out.println(words);
    }
}
